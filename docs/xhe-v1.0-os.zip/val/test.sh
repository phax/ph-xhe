#
sh validate.sh ../xsd/XHE-1.0.xsd simpleExample.xml
sh validate.sh ../xsd/XHE-1.0.xsd simpleExampleTyped.xml
sh validate.sh ../xsd/XHE-1.0.xsd simpleExampleFailSyntax.xml
sh validate.sh ../xsd/XHE-1.0.xsd simpleExampleFailModel.xml
sh validate.sh ../xsd/XHE-1.0.xsd simpleExampleExtension.xml
